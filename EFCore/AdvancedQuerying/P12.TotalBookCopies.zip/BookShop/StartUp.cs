﻿namespace BookShop
{
    using Data;
    using Microsoft.EntityFrameworkCore.Metadata;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext); 

            string result = CountCopiesByAuthor(dbContext);

            Console.WriteLine(result);
        }

        public static string CountCopiesByAuthor(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var copiesByAuthors = context.Authors
                .Select(a => new
                {
                    FullName = a.FirstName + " " + a.LastName,
                    TotalCopies = a.Books.Select(b => b.Copies).Sum()
                })
                .OrderByDescending(a => a.TotalCopies)
                .ToArray();

            foreach (var copiesByAuthor in copiesByAuthors)
            {
                sb.AppendLine($"{copiesByAuthor.FullName} - {copiesByAuthor.TotalCopies}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}