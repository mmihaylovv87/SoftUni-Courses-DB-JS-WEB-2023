﻿namespace BookShop
{
    using Data;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext); 

            string result = GetMostRecentBooks(dbContext);

            Console.WriteLine(result);
        }

        public static string GetMostRecentBooks(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var mostRecentBooks = context.Categories
                .Select(c => new
                {
                    c.Name,
                    Books = c.CategoryBooks
                        .OrderByDescending(b => b.Book.ReleaseDate)
                        .Take(3)
                        .Select(cb => new
                        {
                            cb.Book.Title,
                            Date = cb.Book.ReleaseDate.Value.Year
                        })
                        .ToArray()
                })
                .OrderBy(c => c.Name)
                .ToArray();

            foreach (var category in mostRecentBooks)
            {
                sb.AppendLine($"--{category.Name}");

                foreach (var book in category.Books)
                {
                    sb.AppendLine($"{book.Title} ({book.Date})");
                }
            }

            return sb.ToString().TrimEnd();
        }
    }
}