﻿namespace BookShop
{
    using Data;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext); 

            string input = Console.ReadLine();

            string result = GetBooksByCategory(dbContext, input);

            Console.WriteLine(result);
        }

        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            string[] categories = input.ToLower()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .ToArray();

            var books = context.Books
                .Select(b => new
                {
                    b.Title,
                    Categories = b.BookCategories.Select(bc => bc.Category.Name).ToList()

                })
                .ToList();

            List<string> bookTitles = new List<string>();

            foreach (var category in categories)
            {
                foreach (var book in books)
                {
                    if (book.Categories.Any(c => c.ToLower() == category))
                    {
                        bookTitles.Add(book.Title);
                    }
                }
            }

            StringBuilder sb = new StringBuilder();
           
            foreach (var title in bookTitles.OrderBy(t => t))
            {
                sb.AppendLine(title);
            }

            return sb.ToString().TrimEnd();
        }
    }
}