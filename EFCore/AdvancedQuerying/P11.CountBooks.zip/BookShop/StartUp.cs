﻿namespace BookShop
{
    using Data;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext); 

            int lengthCheck = int.Parse(Console.ReadLine());

            int result = CountBooks(dbContext, lengthCheck);

            Console.WriteLine(result);
        }

        public static int CountBooks(BookShopContext context, int lengthCheck)
        {
            var longerBookTitles = context.Books
                .Where(b => b.Title.Length > lengthCheck)
                .ToArray();

            return longerBookTitles.Length;
        }
    }
}