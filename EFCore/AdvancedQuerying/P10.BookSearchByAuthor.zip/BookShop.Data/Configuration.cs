﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=DESKTOP-T5A7CLB;Database=BookShop;Integrated Security=True;";
    }
}
