﻿namespace BookShop
{
    using Data;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext); 

            string input = Console.ReadLine();

            string result = GetBooksByAuthor(dbContext, input);

            Console.WriteLine(result);
        }

        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            StringBuilder sb = new StringBuilder();

            var booksByAuthor = context.Books
                .Where(b => b.Author.LastName.ToLower().StartsWith(input.ToLower()))
                .OrderBy(b => b.BookId)
                .Select(b => new
                {
                    b.Title,
                    AuthorName = b.Author.FirstName + " " + b.Author.LastName
                })
                .ToArray();

            foreach (var bookByAuthor in booksByAuthor)
            {
                sb.AppendLine($"{bookByAuthor.Title} ({bookByAuthor.AuthorName})");
            }

            return sb.ToString().TrimEnd();
        }
    }
}