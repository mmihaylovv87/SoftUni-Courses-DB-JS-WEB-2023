﻿namespace BookShop
{
    using Data;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext); 

            string result = GetTotalProfitByCategory(dbContext);

            Console.WriteLine(result);
        }

        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var totalProfitByCategories = context.Categories
                .Select(c => new
                {
                    c.Name,
                    TotalProfit = c.CategoryBooks.Select(cb => new
                    {
                        TotalBookPrice = cb.Book.Price * cb.Book.Copies
                    })
                    .Sum(cb => cb.TotalBookPrice)
                })
                .OrderByDescending(c => c.TotalProfit)
                .ThenBy(c => c.Name)
                .ToArray();

            foreach (var totalProfitByCategory in totalProfitByCategories)
            {
                sb.AppendLine($"{totalProfitByCategory.Name} ${totalProfitByCategory.TotalProfit:f2}");
            }

            return sb.ToString().TrimEnd();
        }
    }
}