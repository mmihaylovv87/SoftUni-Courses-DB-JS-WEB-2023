﻿namespace BookShop
{
    using BookShop.Initializer;
    using BookShop.Models.Enums;
    using Data;
    using Microsoft.EntityFrameworkCore.Metadata;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var dbContext = new BookShopContext();
            //DbInitializer.ResetDatabase(dbContext); 

            string input = Console.ReadLine();

            string result = GetAuthorNamesEndingIn(dbContext, input);

            Console.WriteLine(result);
        }

        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            StringBuilder sb = new StringBuilder();

            var authorNamesEndingIn = context.Authors
                .Where(a => a.FirstName.EndsWith(input))
                .Select(a => new
                {
                    FullName = a.FirstName + " " + a.LastName
                })
                .OrderBy(a => a.FullName)
                .ToArray();

            foreach (var authorName in authorNamesEndingIn)
            {
                sb.AppendLine(authorName.FullName);
            }

            return sb.ToString().TrimEnd();
        }
    }
}